<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Prajasattak College</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.css">
        <!--<link rel="stylesheet" href="vendors/linericon/style.css">-->
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <!--<link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">-->
        <!--<link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">-->
        <!--<link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">-->
        <!--<link rel="stylesheet" href="vendors/animate-css/animate.css">-->
        <!--<link rel="stylesheet" href="vendors/popup/magnific-popup.css">-->
        <!-- main css -->
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/responsive.css">
    </head>
    <body>
        
        <!--================Header Menu Area =================-->
        <?php include('includes/header.php') ?>
        <!--================Header Menu Area =================-->
        
        <!--================Home Banner Area =================-->
        <section class="home_banner_area">
            <div class="banner_inner d-flex align-items-center">
            	<div class="overlay bg-parallax" data-stellar-ratio="0.9" data-stellar-vertical-offset="0" data-background=""></div>
				<div class="container">
					<!--<div class="banner_content text-center">
						<h3>We Ensure better education <br />for a better world</h3>
						<p>In the history of modern astronomy, there is probably no one greater leap forward than the building and launch of the space telescope known as the Hubble.</p>
						<a class="main_btn" href="#">Get Started</a>
					</div>-->
				</div>
            </div>
        </section>
        <!--================End Home Banner Area =================-->
        
        <!--================Home Area =================-->
        <section class="courses_area p-50 mt-4">
            <div class="container">
                <div class="row p_50">
                    <div class="col-md-8 col-lg-9" style="border-right: 1px solid #dcd5d5;">
                        <div class="section-header">
                            <h2>Our Vision</h2>
                            <p class="text-justify">The vision of our educational institution is to perform significant function of providing learning experience to lead our students from darkness of ignorance to the light of knowledge.</p>
                        </div>
                        <div class="section-header">
                            <h2>Our Mission</h2>
                            <p class="text-justify">The aim of our college is to provide those facilities which are essential for development of hormonious personality. Teacher training program is related to the development of teacher proficiency and competancy that would unable and empower the teacher to meet the requirement of the profession and challenges there in. It includes effective classroom management skills, preparation and use of instructional material and communication skill. Our institution is also equip students teachers with competence to use ICT for their own professional development.</p>
                        </div>
                        
                    </div>
                    <div class="col-md-4 col-lg-3 border-left text-center">
                        <div class="marquee">
                            <div class="post-content gmd-2 puraskar-ht bodr">
                                <div class="col-md-12 news-hed">
                                    <h3 class="hed3 p-2 tr text-light" key="right_heading1" style="background:#711118;">Notification </h3>
                                </div>
                                <!----------------marquee-------------------------->
                                <div class="container">
                                    <ul style="list-style-type:none;padding: 0px;"> 
                                        <li class="text-left"><a href="pdf/Advertise.pdf" target="_blank"><img src="img/icon/new.gif" style="width:60px;"><b><span style="color:black">Vacancies For Grant-In-Aid Courses/Programmes</span></b>&nbsp;<span style="color:black"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                            <!---------------/marquee-------------------------->
                    </div>
                </div>  
            </div>
        </section>
        <!--================End Home Area =================-->
        
        <!--================Managemnt Photos Area =================-->
        <section class="courses_area p_50_b">
            <div class="container">
                <div class="section-header">
                    <h2>Management Photos</h2>
                </div>
                <div class="row courses_inner">
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <img src="img/management/pic1.jpg" class="img-responsive m-2 manage_p">
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <img src="img/management/pic2.jpg" class="img-responsive m-2 manage_p">
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <img src="img/management/pic3.jpg" class="img-responsive m-2 manage_p">
                    </div>
                    
                </div>
            </div>
        </section>
        <!--================End Management Photos Area =================-->
        
        <!--================ start footer Area  =================-->	
        <?php include('includes/footer.php') ?>
		<!--================ End footer Area  =================-->
        
        
        
        
        
        
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="js/jquery-3.3.1.min.js"></script>
        <script src="js/popper.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <!--<script src="js/stellar.js"></script>-->
        <!--<script src="vendors/lightbox/simpleLightbox.min.js"></script>-->
        <!--<script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>-->
        <!--<script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>-->
        <!--<script src="vendors/isotope/isotope.pkgd.min.js"></script>-->
        <!--<script src="vendors/owl-carousel/owl.carousel.min.js"></script>-->
        <!--<script src="vendors/popup/jquery.magnific-popup.min.js"></script>-->
        <!--<script src="js/jquery.ajaxchimp.min.js"></script>-->
        <!--<script src="vendors/counter-up/jquery.waypoints.min.js"></script>-->
        <!--<script src="vendors/counter-up/jquery.counterup.js"></script>-->
        <!--<script src="js/mail-script.js"></script>-->
        <!--<script src="js/theme.js"></script>-->
    </body>
</html>