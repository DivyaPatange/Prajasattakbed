<style>
        @media screen and (max-width: 1024px) {
         .m {
            margin-left:-50px;
          }
        }
        @media screen and (min-width: 1324px) {
         .m {
            margin-left:-200px;
          }
        }
         @media screen and (max-width: 1324px) {
         .m {
            margin-left:-60px;
          }
        }
        @media screen and (min-width: 1524px) {
         .m {
            margin-left:-300px;
          }
        }
        
</style>       


<header class="header_area">
           	<!-- <div class="top_menu row m0">
           		<div class="container">
					<div class="float-left">
						<ul class="list header_social">
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
							<li><a href="#"><i class="fa fa-behance"></i></a></li>
						</ul>
					</div>
					<div class="float-right">
						<a class="dn_btn" href="tel:+4400123654896">+91 9999999999</a>
						<a class="dn_btn" href="mailto:support@colorlib.com">demo@mail.com</a>
					</div>
           		</div>	
           	</div> -->

            <!-- college name -->
             
                <div class="container-fluid text-center" style="height: 140px; background-color: #ffffff;">
                    <div class="row pb-2">
                        <div class="col-md-2 col-sm-2 col-xs-2 mt-md-4 mt-sm-4 mt-xs-0">
                            <a class=" logo_h" href="index.php"><img src="img/icon/logo.png" class="img_logo" ></a>
                        </div>
                         <div class="col-md-8 col-sm-8 col-xs-8 compress">
                             <p class="mb-sm-0 mt-md-4 p-0 text_m text-lg-center m"><b class="text-dark">Indian Youth & Women's Development Society's</b></p>
                            <h1 class="m-xs-0 text-dark text-size text-lg-center m">Prajasattak College of Education, Nagpur</h1>
                            <p class="mb-md-2 mb-xs-0 text-lg-center m"><strong>Recog by Govt.of Mah., Affiliated by R.T.M. Nagpur University </strong></p>
                        </div>
                         <div class="col-md-2 col-sm-2 col-xs-2 mt-md-4 mt-sm-4 mt-xs-0">
                            
                        </div>
                         
                    </div>
                   
                </div>  
            
            <!-- //college name -->

            <div class="main_menu">
            	<nav class="navbar navbar-expand-lg navbar-light" style="height: 54px;">
					<div class="container">
						<!-- Brand and toggle get grouped for better mobile display -->
						
						<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse offset" id="navbarSupportedContent">
							<ul class="nav navbar-nav menu_nav m-auto">
								<li class="nav-item active"><a class="nav-link text-light text-center" href="index.php">Home</a></li> 
								<li class="nav-item"><a class="nav-link text-light text-center" href="about-us.php">About</a></li>
								<li class="nav-item"><a class="nav-link text-light text-center" href="staff.php">Staff</a></li> 
								<li class="nav-item"><a class="nav-link text-light text-center" href="courses.php">Courses</a></li> 
								<li class="nav-item"><a class="nav-link text-light text-center" href="gallery.php">Gallery</a></li> 
								<li class="nav-item"><a class="nav-link text-light text-center" href="library.php">Library</a></li> 
								<li class="nav-item submenu dropdown">
									<a href="#" class="nav-link dropdown-toggle active text-center" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Syllabus</a>
									<ul class="dropdown-menu">
										<li class="nav-item"><a class="nav-link" href="syllabus.php">B. Ed.</a></li>
										<li class="nav-item"><a class="nav-link" href="#">D. Ed.</a></li>
									</ul>
								</li>
								<li class="nav-item"><a class="nav-link text-light text-center" href="contact.php">Contact</a></li>
							</ul>
						</div> 
					</div>
            	</nav>
            </div>
        </header>
        <!--================Header Menu Area =================-->